package com.example.scode;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 当前是亦乐网络验证单码对接实例
 * 本项目所有代码仅供学习，需要完善更多操作或问题请自行查阅文档，如有疑问请联系作者
 * 后台配置：加密传输选择RC4（请求返回与提交全选择RC4）
 */


public class MainActivity extends AppCompatActivity {

    //接口地址
    static String host = "http://192.168.1.88:81/api/HCGZOJoN0z";
    //加密密钥
    static String rc4Key = "123456";
    //设备mac【这里为了方便，直接设置固定】
    static String mac = "00-00-00-00-00-00";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button login = findViewById(R.id.login);
        EditText card = findViewById(R.id.card);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (card.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "请输入激活码", Toast.LENGTH_SHORT).show();
                }

                String text = card.getText().toString(); // 获取编辑框内容

                OkHttpClient client = new OkHttpClient();
                // 创建请求体
                String payload;
                try {
                    payload = RC4Util.encryRC4String("scode=" + text + "&mac="+mac, rc4Key, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
                RequestBody requestBody = new FormBody.Builder().add("data", payload).build();

// 创建一个 POST 请求
                Request request = new Request.Builder().url(host).post(requestBody).build();

// 发起请求并处理响应
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        // 处理请求失败
                        final String errorMessage = "Request failed: " + e.getMessage();
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show());
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        if (response.isSuccessful()) {
                            String responseData = response.body().string();
                            // 处理成功响应
                            String result = RC4Util.decryRC4(responseData, "123456", "UTF-8");
// 使用 JsonObject 解析 JSON 字符串
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(result);
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                            int code;
                            try {
                                code = jsonObject.getInt("code");
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                            String msg;
                            try {
                                msg = jsonObject.getString("explain");
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                            if (code == 200) {
                                // 登录成功
                                runOnUiThread(() -> Toast.makeText(MainActivity.this, "登录成功", Toast.LENGTH_SHORT).show());
                            } else {
                                // 登录失败
                                runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
                            }
                        } else {
                            // 处理失败响应
                            final String errorMessage = "Request failed with code: " + response.code();
                            runOnUiThread(() -> Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show());
                        }
                    }
                });

            }
        });
    }
}