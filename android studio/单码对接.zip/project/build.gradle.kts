// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.androidApplication) apply false
}
// 在项目的 build.gradle.kts 文件中添加 JitPack 仓库的引入
//repositories {
//    // 其他仓库
//    maven("https://jitpack.io")
//}